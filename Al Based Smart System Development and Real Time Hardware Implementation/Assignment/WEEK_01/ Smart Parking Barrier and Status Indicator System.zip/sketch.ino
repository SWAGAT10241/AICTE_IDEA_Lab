#include <ESP32Servo.h>

const int RED = 25;
const int GREEN = 26;
const int BLUE = 27;

Servo myServo;

const int potPin = 34;

void setColor(int red,int green,int blue){
  analogWrite(RED,red);
  analogWrite(GREEN,green);
  analogWrite(BLUE,blue);
}

void setAngle(int angle){
  myServo.write(angle);
}

void setup() {
  Serial.begin(115200);

  pinMode(RED, OUTPUT);
  pinMode(GREEN, OUTPUT);
  pinMode(BLUE, OUTPUT);

  myServo.attach(18);
}

void loop() {
  int potValue = analogRead(potPin);

  // 0 – 1365 -- red -- 0
  if (potValue >= 0 && potValue <= 1365){
    setAngle(0);
    setColor(255,0,0);
    Serial.println("Parking Full");

  }
  // 1365 - 2730  -- yellow -- 90
  else if (potValue > 1365 && potValue <= 2730){
    setAngle(90);
    setColor(255,255,0);
    Serial.println("Limited Space");

  }
  // 2731 – 4095  -- green -- 180
  else if (potValue > 2730 && potValue <= 4095){
    setAngle(180);
    setColor(0,255,0);
    Serial.println("Parking Available");

  }
    delay(2000);
}
