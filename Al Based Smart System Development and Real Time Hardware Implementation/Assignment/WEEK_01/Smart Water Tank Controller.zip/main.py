from machine import Pin, ADC, PWM
from time import sleep

RED = PWM(Pin(25,Pin.OUT))
GREEN = PWM(Pin(26,Pin.OUT))
BLUE = PWM(Pin(27,Pin.OUT))

servo = PWM(Pin(18),freq = 50)

pot = ADC(Pin(34))
pot.atten(ADC.ATTN_11DB)

def setColor(red ,green ,blue ):
    RED.duty(int(red * 1023 / 255)) 
    GREEN.duty(int(green * 1023 / 255)) 
    BLUE.duty(int(blue * 1023 / 255)) 

def setAngle(angle):
    duty = int(20 + (angle / 180) * 100)
    servo.duty(duty)

while True:
    value = pot.read()
    percentage = int((value * 100) / 4095)

# 0 – 33 % -- red -- 180
    if (0 <= percentage <= 33):
        setAngle(180)
        setColor(255,0,0)
        print(f"Low Level! Level: {percentage}%")

# 34 - 66 %  -- yellow -- 90
    elif (33 < percentage <= 66):
        setAngle(90)
        setColor(255,255,0)
        print(f"Medium Level! Level: {percentage}%")

# 67 – 100 %  -- green -- 0
    elif (66 < percentage <= 100):
        setAngle(0)
        setColor(0,255,0)
        print(f"Tank Full! Level: {percentage}%")
    sleep(1)
