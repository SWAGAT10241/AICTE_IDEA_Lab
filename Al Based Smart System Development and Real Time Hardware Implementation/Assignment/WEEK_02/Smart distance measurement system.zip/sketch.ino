#include <Wire.h>
#include <LiquidCrystal_I2C.h>

const int TRIG_PIN = 5;
const int ECHO_PIN = 18;

LiquidCrystal_I2C lcd(0x27,16,2);

void setup() {
  // put your setup code here, to run once:
  Serial.begin(115200);
  pinMode(TRIG_PIN,OUTPUT);
  pinMode(ECHO_PIN,INPUT);

  lcd.init();
  lcd.backlight();
  lcd.clear();

  Serial.println("Smart Parking System");
  delay(1000);
}

void loop() {
  // put your main code here, to run repeatedly:
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);

  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);

  digitalWrite(TRIG_PIN, LOW);

  long duration = pulseIn(ECHO_PIN,HIGH);

  float distance = duration * 0.0343 / 2.0;
  Serial.print("Distance = ");
  Serial.print(distance);
  Serial.println(" cm");

  lcd.setCursor(3,0);

  if (distance < 10){
    lcd.print("DANGER!!!");
    Serial.println("DANGER");
  }
  else if(distance < 30){
    lcd.print("CAUTION");
    Serial.println("CAUTION");
  }
  else{
    lcd.print("SAFE");
    Serial.println("SAFE");
  }
  delay(200);
}
