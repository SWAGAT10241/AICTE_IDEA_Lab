const int redPin = 25;
const int greenPin = 26;
const int bluePin = 27;

void setColour(int rValue, int gValue, int bValue){
  analogWrite(redPin, rValue);
  analogWrite(greenPin, gValue);
  analogWrite(bluePin, bValue);
}

void setup() {
  Serial.begin(115200);
  Serial.println("Hello, ESP32 RGB Control!");
  
  pinMode(redPin, OUTPUT);
  pinMode(greenPin, OUTPUT);
  pinMode(bluePin, OUTPUT);
}

void loop() {
  // 1. White (All colors fully on)
  setColour(255, 255, 255); 
  delay(1000); 

  // 2. Magenta (Red + Blue)
  setColour(255, 0, 255); 
  delay(1000); 

  // 3. Cyan (Green + Blue)
  setColour(0, 255, 255); 
  delay(1000); 

  // 4. Yellow (Red + Green)
  setColour(255, 255, 0); 
  delay(1000); 
}