# include <ESP32Servo.h>

Servo myServo;

const int potPin = 14;

void setup() {
  myServo.attach(10);
  Serial.begin(115200); 

}

void loop() {
  int potValue = analogRead(potPin);

  int angle = map(potValue,0,4095,0,180);

  Serial.print("Angle = ");
  Serial.println(angle);

  delay(10);
}