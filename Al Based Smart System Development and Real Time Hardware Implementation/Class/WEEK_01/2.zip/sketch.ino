const int RED_PIN = 25;

void setup() {
  // put your setup code here, to run once:
  Serial.begin(115200);
  Serial.println("Hello, ESP32!");
  pinMode(RED_PIN, OUTPUT);
}

void loop() {
  // put your main code here, to run repeatedly:

  for(int brightness = 0 ; brightness <= 255 ; brightness++)
  {
    analogWrite(RED_PIN,brightness);
    delay(10);
  }

  for(int brightness = 255 ; brightness >= 0 ; brightness--)
  {
    analogWrite(RED_PIN,brightness);
    delay(10);
  }
}
