// Assign unique GPIO pins for each color channel
const int RED_PIN = 25;
const int GREEN_PIN = 26;
const int BLUE_PIN = 27;

void setColour(int rValue, int gValue, int bValue){
  analogWrite(RED_PIN, rValue);
  analogWrite(GREEN_PIN, gValue);
  analogWrite(BLUE_PIN, bValue);
}

void setup() {
  Serial.begin(115200);
  Serial.println("Hello, ESP32!");
  
  pinMode(RED_PIN, OUTPUT);
  pinMode(GREEN_PIN, OUTPUT);
  pinMode(BLUE_PIN, OUTPUT);
}

void loop() {
  // Fixed the increment to i += 25
  for(int i = 0 ; i <= 255 ; i += 25)
  {
    setColour(i, 0, 0); // Fade Red up
    delay(500);
  }

  for(int i = 0 ; i <= 255 ; i += 25)
  {
    setColour(0, i, 0); // Fade Green up
    delay(500);
  }
}