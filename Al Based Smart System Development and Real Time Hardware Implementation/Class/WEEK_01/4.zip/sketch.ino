#include <ESP32Servo.h>

Servo myServo;

void setup() {
  myServo.attach(18);
}

void loop() {
  myServo.write(30);
  delay(1000);
  myServo.write(45);
  delay(1000);
  myServo.write(90);
  delay(1000);
  myServo.write(120);
  delay(1000);
  myServo.write(180);
  delay(1000);
}
