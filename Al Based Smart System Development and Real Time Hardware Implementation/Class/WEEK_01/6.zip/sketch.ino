#include <ESP32Servo.h>

Servo myServo;

void moveServo(int startAngle, int endAngle, int speedDelay) {
  if (startAngle < endAngle) {
    for (int angle = startAngle; angle <= endAngle; angle++) {
      myServo.write(angle);
      delay(speedDelay);
    }
  }
  else {
    for (int angle = startAngle; angle >= endAngle; angle--) {
      myServo.write(angle);
      delay(speedDelay);
    }
  }
}

void setup() {
  myServo.attach(18); 
}

void loop() {
  moveServo(0, 180, 0);
  delay(1000);
  
  moveServo(180, 0, 30);
  delay(1000);
}