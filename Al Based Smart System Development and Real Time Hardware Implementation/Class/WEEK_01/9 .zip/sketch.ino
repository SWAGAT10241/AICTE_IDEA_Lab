const int potPin = 34;

void setColor(int r,int g,int b){
  analogWrite(2,r);
  analogWrite(4,g);
  analogWrite(16,b);
}

void setup() {
  // Serial.begin(115200); 

}

void loop() {
  int potValue = analogRead(potPin);

  int brightness = map(potValue,0,4095,0,255);

  setColor(brightness,0,0);

  delay(10);
}