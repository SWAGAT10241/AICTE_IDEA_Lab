from machine import Pin
import time

bled = Pin(0,Pin.OUT)
gled = Pin(1,Pin.OUT)
rled = Pin(2,Pin.OUT)
while True:
    bled.value(1)
    time.sleep(1)
    bled.value(0)
    time.sleep(1)
    gled.value(1)
    time.sleep(1)
    gled.value(0)
    time.sleep(1)
    rled.value(1)
    time.sleep(1)
    rled.value(0)
    time.sleep(1)
