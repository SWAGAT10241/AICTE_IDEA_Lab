from machine import Pin,PWM
import utime
import random

rled = PWM(Pin(2),freq=2000)
gled = PWM(Pin(1),freq=2000)
bled = PWM(Pin(0),freq=2000)

while True:
    rled.duty_u16(65535)
    utime.sleep(1)
    rled.duty_u16(0)
    utime.sleep(1)
    gled.duty_u16(65535)
    utime.sleep(1)
    gled.duty_u16(0)
    utime.sleep(1)
    bled.duty_u16(65535)
    utime.sleep(1)
    bled.duty_u16(0)
    utime.sleep(3)