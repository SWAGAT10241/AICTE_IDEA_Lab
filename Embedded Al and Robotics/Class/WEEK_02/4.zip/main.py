from machine import Pin,PWM
import utime
import random

rled = PWM(Pin(2),freq=2000)
gled = PWM(Pin(1),freq=2000)
bled = PWM(Pin(0),freq=2000)

while True:
    R = random.randint(0,65535)
    G = random.randint(0,65535)
    B = random.randint(0,65535)
    print(R,G,B)
    rled.duty_u16(R)
    gled.duty_u16(B)
    bled.duty_u16(G)
    utime.sleep(3)