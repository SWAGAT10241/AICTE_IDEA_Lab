from machine import Pin,PWM
import utime
import random

rled = PWM(Pin(2),freq=2000)
gled = PWM(Pin(1),freq=2000)
bled = PWM(Pin(0),freq=2000)

button = Pin(4,Pin.IN,Pin.PULL_UP)

def setColor(r,g,b):
    rled.duty_u16(r)
    gled.duty_u16(g)
    bled.duty_u16(b)

setColor(0,0,0)

while True:
    if button.value() == 0:
        utime.sleep(0.05)
        if button.value() == 0:

            R = random.randint(0,65535)
            G = random.randint(0,65535)
            B = random.randint(0,65535)
        
            print(f"Instant Color -> Red : {R} , Green : {G} , Blue : {B}")
            setColor(R,G,B)

            while button.value() == 0:
                utime.sleep(0.05)
utime.sleep(0.01)