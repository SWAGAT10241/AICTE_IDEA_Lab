import machine
import utime

buzzer = machine.Pin(1,machine.Pin.OUT)

button = machine.Pin(7,machine.Pin.IN,machine.Pin.PULL_UP)

while True:
    if button.value() == 0:
        buzzer.value(1)
    else:
        buzzer.value(0)
utime.sleep(0.05)