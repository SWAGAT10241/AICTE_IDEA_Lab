from machine import Pin,PWM
import utime

buzzer = machine.PWM(machine.Pin(1))

button = machine.Pin(7,machine.Pin.IN,machine.Pin.PULL_UP)

TONE_LOW = 262
TONE_MED = 440
TONE_HIGH = 880

VOLUME_ON = 32768
VOLUME_OF = 0

while True:
    if button.value() == 0:
        # Play Low Tone
        buzzer.freq(TONE_LOW)
        buzzer.duty_u16(VOLUME_ON)
        utime.sleep(0.3)

        # Play Medium Tone
        buzzer.freq(TONE_MED)
        buzzer.duty_u16(VOLUME_ON)
        utime.sleep(0.3)

        # Play High Tone
        buzzer.freq(TONE_HIGH)
        buzzer.duty_u16(VOLUME_ON)
        utime.sleep(0.3)

    while button.value() == 0:
        utime.sleep(0.05)

utime.sleep(0.05)