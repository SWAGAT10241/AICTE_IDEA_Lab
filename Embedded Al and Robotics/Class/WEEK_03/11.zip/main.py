from machine import Pin, I2C
from ssd1306 import SSD1306_I2C
import time

WIDTH = 128
HEIGHT = 64

i2c = I2C(0, scl = Pin(17), sda = Pin(16), freq=400000)
display = SSD1306_I2C(WIDTH, HEIGHT, i2c)

def read_temp():
    sensor_temp = machine.ADC(4)
    conversion_factor = 3.3 / (65535)
    reading = sensor_temp.read_u16() * conversion_factor
    temperature = 27 - (reading - 0.706)/0.001721

    formatted_temperature = "{:.1f}".format(temperature)
    string_temperature = str("Int_Temp:" + formatted_temperature)
    print(string_temperature)
    time.sleep(2)
    return string_temperature
    
while True:
    display.text('Welcome to ',0,0)
    display.text('AICTE IDEA LAB',0,12)
    display.text('Example 1:', 0,24)
    temperature = read_temp()
    display.text(temperature,0,48)
    display.show()
    display.fill(0)