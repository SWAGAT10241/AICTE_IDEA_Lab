from machine import Pin
import utime

pin_list = [0,1,2,3,4,5,6,7]
L = [0]*8

for i in range (8):
    L[i] = Pin(pin_list[i],Pin.OUT)
#Common Cathode display
chars = [
    [1,1,1,1,1,1,0,0], #0
    [0,1,1,0,0,0,0,0], #1
    [1,1,0,1,1,0,1,0], #2
    [1,1,1,1,0,0,1,0], #3
    [0,1,1,0,0,1,1,0], #4
    [1,0,1,1,0,1,1,0], #5
    [1,0,1,1,1,1,1,0], #6
    [1,1,1,0,0,0,0,0], #7
    [1,1,1,1,1,1,1,0], #8
    [1,1,1,1,0,1,1,0], #9
    [0,0,0,0,0,0,0,1] #dot
]
for i in pin_list:
    L[i].value(0)

while True:
    for i in range(len(chars)):
        for j in range(len(pin_list)):
            L[j].value(chars[i][j])
        utime.sleep(1)
    for i in range(len(chars)-1,-1,-1):
        for j in range(len(pin_list)):
            L[j].value(chars[i][j])
        utime.sleep(1)
    utime.sleep(0.5)