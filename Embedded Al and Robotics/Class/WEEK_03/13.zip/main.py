from neopixel import Neopixel
import utime
import random

numpix = 8
strip = Neopixel(numpix, 0, 2, "RGB")

red = (255, 0, 0)
orange = (255, 50, 0)
yellow = (255, 100, 0)
green = (0, 255, 0)
blue = (0, 0, 255)
indigo = (100, 0, 90)
violet = (200, 0, 100)
colors_rgb = [red, orange, yellow, green, blue, indigo, violet]

delay = 0.5
strip.brightness(200)
blank = (0,0,0)

while True:
#Controlling individual leds
    strip.set_pixel(random.randint(0, numpix-1), colors_rgb[random.randint(0,len(colors_rgb)-1)])
    strip.set_pixel(random.randint(0, numpix-1), colors_rgb[random.randint(0,len(colors_rgb)-1)])
    strip.set_pixel(random.randint(0, numpix-1), colors_rgb[random.randint(0,len(colors_rgb)-1)])
    strip.set_pixel(random.randint(0, numpix-1), colors_rgb[random.randint(0,len(colors_rgb)-1)])
    strip.set_pixel(random.randint(0, numpix-1), colors_rgb[random.randint(0,len(colors_rgb)-1)])
    strip.set_pixel(random.randint(0, numpix-1), colors_rgb[random.randint(0,len(colors_rgb)-1)])
    strip.set_pixel(random.randint(0, numpix-1), colors_rgb[random.randint(0,len(colors_rgb)-1)])
    strip.set_pixel(random.randint(0, numpix-1), colors_rgb[random.randint(0,len(colors_rgb)-1)])
    strip.show()
    utime.sleep(delay)
    strip.fill((0,0,0))